import { App } from '../system/App';
import { Platform } from './Platform';
import { Hero } from './Hero';

export class GameScene extends App.Scene {
    constructor() {
        super();
        this.platforms = [];
        this.hero = new Hero();
        this.addChild(this.hero.sprite);
        this.createPlatforms();
        App.physics.addCollider(this.hero.body, (platform) => {
            if (platform.gamePlatform) {
                this.hero.landOnPlatform(platform.gamePlatform);
            }
        });