import * as Matter from 'matter-js';
import { App } from '../system/App';

export class Hero {
    constructor() {
        this.sprite = App.sprite('hero');
        this.sprite.x = App.config.hero.position.x;
        this.sprite.y = App.config.hero.position.y;
        this.sprite.anchor.set(0.5);
        this.sprite.loop = true;
        this.sprite.animationSpeed = 0.1;
        this.sprite.play();
        this.createBody();
        App.app.ticker.add(this.update, this);
    }

    createBody() {
        this.body = Matter.Bodies.rectangle(this.sprite.x + this.sprite.width / 2, this.sprite.y + this.sprite.height / 2, this.sprite.width, this.sprite.height, {friction: 0});
        Matter.World.add(App.physics.world, this.body);
        this.body.gameHero = this;
    }

    update(delta) {
        this.body.position.x = this.sprite.x + this.sprite.width / 2;
        this.body.position.y = this.sprite.y + this.sprite.height / 2;
    }
}