import * as Matter from 'matter-js';
import { App } from '../system/App';

export class Platform {
    constructor(rows, cols, x) {
        this.rows = rows;
        this.cols = cols;
        this.width = cols * App.config.platform.width;
        this.height = rows * App.config.platform.height;
        this.container = new PIXI.Container();
        this.createTiles();
        this.x = x;
        this.y = App.config.platform.y;
        this.createBody();
    }

    createTiles() {
        for (let row = 0; row < this.rows; row++) {
            for (let col = 0; col < this.cols; col++) {
                const tile = App.sprite('platform');
                tile.x = col * App.config.platform.width;
                tile.y = row * App.config.platform.height;
                this.container.addChild(tile);
            }
        }
    }

    createBody() {
        this.body = Matter.Bodies.rectangle(this.x + this.width / 2, this.y + this.height / 2, this.width, this.height, {friction: 0, isStatic: true});
        Matter.World.add(App.physics.world, this.body);
        this.body.gamePlatform = this;
    }

    move() {
        if (this.body) {
            Matter.Body.setPosition(this.body, {x: this.body.position.x + this.body.dx, y: this.body.position.y});
            this.x = this.body.position.x - this.width / 2;
            this.y = this.body.position.y - this.height / 2;
        }
    }
}